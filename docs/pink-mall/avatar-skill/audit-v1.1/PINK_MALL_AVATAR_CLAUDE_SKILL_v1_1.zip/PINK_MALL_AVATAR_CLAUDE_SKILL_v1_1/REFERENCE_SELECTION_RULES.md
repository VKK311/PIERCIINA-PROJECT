# PINK MALL Avatar Reference Selection Rules v1.0

## Purpose

This library is a retrieval system, not a dump of every available photograph into every image-generation request. The goal is to select the smallest set of references that provides independent, non-conflicting information about identity, angle, body geometry, expression, pose, product interaction and duo composition.

## Mandatory selection order

1. Identify the subject: `INA`, `SIS`, or `DUO`.
2. Start with identity anchors. For one sister, normally use `FACE_FRONT` plus the face angle nearest the requested view. For full-body work add `BODY_FRONT` plus the matching body angle.
3. Add exactly one task-specific pose reference when a pose is important.
4. Add a product-specific reference for eyewear/headwear/accessory tasks.
5. Add an expression reference only when the requested expression is materially different from neutral.
6. For duo work, select identity anchors for both sisters first, then add one or two DUO composition references.
7. Stop adding references when every image has a distinct job. Redundant references increase ambiguity.

## Default pack sizes

Single subject: 4–6 reference images.
Two sisters: 6–8 total reference images.
Use 8–10 only when each image contributes unique information.

## Identity separation

Never allow INA and SIS references to become an unlabeled mixed pool. Every selected image must keep its subject label.

DUO photographs teach composition and interpersonal geometry. They do not replace clean single-subject face and body anchors.

## Reference priority

`CORE_IDENTITY` > `POSE_MASTER` / `DUO_MASTER` > `EXTENDED_REFERENCE` > `SELECT` > `ARCHIVE`.

If a higher-priority image conflicts with a lower-priority image, preserve the higher-priority identity geometry and use the lower-priority image only for pose/styling.

## Task recipes

### Portrait
FACE_FRONT + requested FACE_45/PROFILE + expression reference if needed.

### Full-body fashion
FACE_FRONT + BODY_FRONT + requested BODY_ANGLE + one POSE_MASTER.

### Eyewear
FACE_FRONT + relevant FACE_45 + one EYEWEAR reference + product image.

### Headwear
FACE_FRONT + relevant FACE_45 + one HEADWEAR reference + product image.

### Motion
FACE_FRONT + BODY_FRONT + one body angle + one MOTION reference.

### Duo hero/banner
INA FACE + INA BODY + SIS FACE + SIS BODY + one primary DUO composition + optionally one alternate DUO composition.

## Failure conditions

Do not claim a strong identity lock when the needed angle/detail is absent.
Do not invent permanent piercings, tattoos, hair changes or facial characteristics.
Do not use a DUO frame to decide which face belongs to which sister when clean solo references exist.
Do not select the full archive by default.
