# PINK MALL Avatar Claude Skill v1.1 — Test Edition

This package upgrades the v1.0 avatar retrieval system into a **reference selector + creative identity controller** for PINK MALL / Pierciina visual work.

## What is stable from v1.0

- 190-image manifest: 77 INA / 76 SIS / 37 DUO
- canonical reference packs
- INA/SIS Avatar Bibles
- DUO composition library
- compact-reference selection rules

The image files themselves are not duplicated in this package. Paths refer to the subject folders inside the supplied `Avatarskill.rar` archive.

## What is new in v1.1

- `BRAND_DNA.json`
- `SISTER_STYLE_PROFILES.json`
- `CAMPAIGN_STYLE_PRESETS.json`
- `CREATIVE_GUARDRAILS.md`
- `PROMPT_ASSEMBLY_RULES.md`
- `WORKFLOW_5_STEP.md`
- `TEST_SCENARIOS.json`
- `TEST_EVALUATION_RUBRIC.json`
- `IMAGE_LIBRARY_INTEGRATION_POLICY.md`
- `VALIDATE_SKILL.py`
- `GITHUB_INTEGRATION_TASK.md`

## Start here

1. Run `python VALIDATE_SKILL.py`.
2. Read `SKILL.md`.
3. Read `WORKFLOW_5_STEP.md`.
4. Use `TEST_SCENARIOS.json` for the first controlled generation round.
5. Score results with `TEST_EVALUATION_RUBRIC.json` before changing canonical rules.

## Important distinction

Identity manifests and image evidence define **who INA and SIS are**.

`BRAND_DNA.json`, `SISTER_STYLE_PROFILES.json` and campaign presets define **how they are art-directed for PINK MALL**. Creative profiles are testable defaults and can evolve without changing identity versions.

## GitHub media note

The full 190-image source archive is approximately 195 MB. Read `IMAGE_LIBRARY_INTEGRATION_POLICY.md` before committing image binaries. Do not bulk-add the library without checking the repository's media/LFS policy.
