# CLAUDE TASK — PINK MALL AVATAR SKILL v1.1 REVIEW + GITHUB INTEGRATION

You are integrating a **test-phase avatar reference and creative-direction skill** into the PIERCIINA / PINK MALL repository.

## Inputs supplied by owner

1. `PINK_MALL_AVATAR_CLAUDE_SKILL_v1_1.zip`
2. `Avatarskill.rar` — source image archive containing the referenced INA / SIS / DUO images

The v1.1 package contains the previously curated v1.0 identity evidence plus new creative-context and test layers.

## Mission

Review the package independently, validate it, integrate the skill into the repository in a way that follows existing repo conventions, and prepare it for controlled campaign testing.

This task is **not** permission to alter the PINK MALL storefront, publish campaigns, redefine canonical avatar identities, or bulk-import media without validating the repository media policy.

---

## 0. REPO SAFETY — DO THIS FIRST

Before any write:

1. Inspect the repository and current branch/HEAD.
2. Read the live `docs/pink-mall/PROJECT_STATE.md` and any current project instructions / CLAUDE.md files.
3. Confirm existing conventions for skills, documentation, media storage and Git LFS.
4. Never work on or push directly to `main`.
5. Never force-push.
6. Do not modify `PINKMALL.html`, `PINKMALL_REVIEW_STANDALONE.html`, product data, jewelry data, media-acquisition workflows or unrelated Mall code in this task.
7. If the expected development branch is not unambiguous, use/create a dedicated branch such as:
   `claude/pink-mall-avatar-skill-v1-1`
   rather than guessing or touching main.

---

## 1. VERIFY THE PACKAGE BEFORE INTEGRATION

Extract `PINK_MALL_AVATAR_CLAUDE_SKILL_v1_1.zip` into a temporary workspace.

Run:

```bash
python VALIDATE_SKILL.py
```

It must PASS.

Independently verify at minimum:

- all JSON files parse;
- manifest contains exactly 190 records;
- subject counts are exactly 77 INA / 76 SIS / 37 DUO;
- canonical-pack and DUO paths resolve to manifest records;
- no canonical reference crosses subject labels;
- campaign presets referenced by test scenarios exist;
- evaluation weights total 1.0;
- `INA_v1.0` and `SIS_v1.0` remain `CURATED_FOUNDATION_CANDIDATE` unless owner has separately approved them;
- style profiles are clearly labeled creative hypotheses/defaults, not identity facts.

If any of these fail, STOP and report the exact failure. Do not silently repair identity mappings.

---

## 2. VERIFY SOURCE IMAGE LIBRARY

Inspect `Avatarskill.rar`.

Expected source-library identity from the supplied skill manifest:

- total images: 190
- INA: 77
- SIS: 76
- DUO: 37

Use `AVATAR_LIBRARY_MANIFEST.json` SHA-256 values to spot-check and, where practical, fully verify extracted files.

Do not rename or regroup source images during this integration unless the manifest and all dependent references are updated atomically and validation still passes.

### Important media policy

The full archive is large. Read `IMAGE_LIBRARY_INTEGRATION_POLICY.md` and inspect repository conventions before adding binaries.

Do **not** blindly commit all 190 JPEGs to normal Git.

If the repository already has an approved Git LFS or equivalent media strategy, propose/use it according to existing project rules.

If no safe media strategy exists, integrate the skill metadata/instructions first and report one of these owner-review options:

A. Git LFS for full library;
B. only canonical reference subset stored with the repo;
C. existing external/media-acquisition storage convention.

Do not claim the image library is GitHub-connected unless actual images are accessible to future sessions and their hashes were verified.

---

## 3. INTEGRATE USING EXISTING REPO CONVENTIONS

Prefer the repository's current structure. Do not invent a competing project layout if a suitable one already exists.

The integrated skill must retain these logical components:

### Identity/evidence
- `AVATAR_LIBRARY_MANIFEST.json`
- `CANONICAL_PACKS.json`
- `INA_AVATAR_BIBLE.json`
- `SIS_AVATAR_BIBLE.json`
- `DUO_LIBRARY.json`
- `REFERENCE_SELECTION_RULES.md`

### Creative context
- `BRAND_DNA.json`
- `SISTER_STYLE_PROFILES.json`
- `CAMPAIGN_STYLE_PRESETS.json`
- `CREATIVE_GUARDRAILS.md`
- `PROMPT_ASSEMBLY_RULES.md`
- `WORKFLOW_5_STEP.md`

### Test/QA
- `TEST_SCENARIOS.json`
- `TEST_EVALUATION_RUBRIC.json`
- `VALIDATE_SKILL.py`
- `IMAGE_LIBRARY_INTEGRATION_POLICY.md`
- README / changelog / prior audit report as appropriate

### Claude project activation

If the repository uses `CLAUDE.md` project instructions, integrate/import this skill using the existing style rather than replacing unrelated instructions.

The activation rule must be functionally equivalent to:

> For any visual task depicting INA, SIS or both, run the Avatar Reference + Creative Orchestrator before generation planning. Preserve separate identities and use the canonical 5-step workflow.

Do not make the entire PINK MALL project load large manifests unnecessarily for unrelated code tasks if the repo already supports scoped instructions/skills.

---

## 4. PRESERVE THE 5-STEP CONTRACT

The integrated system must execute in this order:

1. Identity & reference selection
2. Brand DNA
3. Sister creative profile
4. Campaign preset / product logic
5. Creative guardrails + prompt assembly + test logging

Conflict priority must remain:

`identity > product accuracy > campaign clarity > brand character > creative flourish`

The style profiles must remain owner-editable creative defaults. They must never overwrite or mutate biometric/identity records.

---

## 5. FIRST CONTROLLED TEST SET

Do not publish generated images as production assets in this task.

Prepare the system so the owner can run these controlled tests from `TEST_SCENARIOS.json`:

- T01 INA HERO
- T02 SIS ACCESSORY
- T03 DUO HERO
- T04 SISTER BATTLE
- T05 VERTICAL STORY
- T06 WEIRD EDITORIAL STRESS TEST

For each test, the skill must first produce a structured reference-pack/generation handoff before any image-generation step.

The evaluation contract is `TEST_EVALUATION_RUBRIC.json`.

Hard gates:

- identity likeness >= 8/10;
- product fidelity >= 8/10 when product-led;
- sister distinction >= 8/10 for DUO.

A high average score must not override a failed hard gate.

---

## 6. REQUIRED VALIDATION AFTER INTEGRATION

Run the validator from its final repo location.

Also verify:

- no path breaks introduced by repo placement;
- all JSON references remain internally valid;
- no INA/SIS cross-label contamination;
- no unrelated PINK MALL files changed;
- `git diff --stat` and full diff contain only intended avatar-skill integration changes;
- repository status is clean after commit if you commit.

If you add a repo-specific validation wrapper or test, keep it small and dependency-light.

---

## 7. GIT POLICY

You may commit and push this **skill integration** only to the non-main working/development branch after all validation passes.

Never push to main.
Never force-push.
Do not merge to main.
Do not publish visual campaign outputs.

If media-storage policy requires an owner decision, commit only the safe metadata/skill integration if that is useful and explicitly mark media connection as pending; otherwise stop before the ambiguous media write.

---

## 8. FINAL REPORT FORMAT

Return:

### A. PACKAGE VALIDATION
- validator result
- 190-image manifest counts
- canonical/DUO reference integrity

### B. INTEGRATION
- branch
- commit hash (if committed)
- exact repository paths added/changed
- whether/where image binaries are available to future Claude sessions

### C. MEDIA DECISION
- existing repository media strategy found
- what was integrated
- what remains owner-dependent

### D. SAFETY / DIFF
- confirm `main` untouched
- confirm `PINKMALL.html` untouched
- confirm unrelated product/jewelry/storefront code untouched

### E. TEST READINESS
- confirm T01–T06 can be executed using the integrated skill
- list any blocker before real generation testing

Final status must be exactly one of:

`READY FOR OWNER REVIEW — AVATAR SKILL v1.1 INTEGRATED`

or

`BLOCKED — <exact reason>`
