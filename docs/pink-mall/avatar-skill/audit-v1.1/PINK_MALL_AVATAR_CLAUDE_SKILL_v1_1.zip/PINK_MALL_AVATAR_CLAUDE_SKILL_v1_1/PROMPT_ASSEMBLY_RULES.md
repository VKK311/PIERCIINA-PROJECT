# PINK MALL Prompt Assembly Rules v1.1

## Purpose

Convert a visual brief into a compact, evidence-grounded reference pack plus a consistent creative brief.

## Mandatory assembly sequence

### 1. SUBJECT
Determine `INA`, `SIS`, or `DUO`.

### 2. IDENTITY PACK
Load canonical identity anchors from `CANONICAL_PACKS.json` and the corresponding Avatar Bible. Identity selection always happens before styling.

### 3. CAMPAIGN PRESET
Choose the closest preset in `CAMPAIGN_STYLE_PRESETS.json`. If none fits, create a temporary task-local preset without editing the canonical file unless the owner later approves it.

### 4. BRAND + SISTER STYLE
Apply `BRAND_DNA.json` and the relevant entry from `SISTER_STYLE_PROFILES.json`.

Treat sister style profiles as creative defaults. Do not convert them into biometric or personal claims.

### 5. TASK-SPECIFIC REFERENCES
Add only references with distinct jobs: requested angle, pose, expression, product interaction, motion or DUO composition. Follow `REFERENCE_SELECTION_RULES.md`.

### 6. PRODUCT REFERENCE
If a real product is involved, include its authoritative product image/source separately from avatar references and state that product fidelity is locked.

### 7. GUARDRAILS
Apply `CREATIVE_GUARDRAILS.md`. Resolve conflicts in this order:

`identity > product > campaign clarity > brand > creative flourish`

### 8. OUTPUT THE GENERATION HANDOFF
Before generation, produce this structure:

```json
{
  "task": "...",
  "subjects": ["INA"],
  "campaignPreset": "hero_banner",
  "selectedReferences": [
    {
      "path": "INA/IMG_3854.JPEG",
      "role": "FACE_FRONT identity anchor",
      "priority": 1
    }
  ],
  "identityLocks": [],
  "productLocks": [],
  "brandDirectives": [],
  "sisterStyleDirectives": [],
  "compositionDirectives": [],
  "negativeSpaceRequirement": "...",
  "format": "...",
  "warnings": [],
  "confidence": "HIGH"
}
```

Then write the final image-generation brief using the same facts. Do not add unsupported identity details while translating the structured handoff into prose.

## Reference-count default

- Single sister: 4–6 references.
- DUO: 6–8 references total.
- 8–10 is acceptable only when every reference contributes unique information.

Stop adding images when every important requirement has an evidence source.
