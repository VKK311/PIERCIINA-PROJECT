# Changelog

## v1.1 — Test Edition

- Kept the v1.0 190-image evidence library and canonical packs unchanged.
- Added PINK MALL / Pierciina Brand DNA.
- Added owner-editable INA/SIS/DUO creative roles, explicitly separated from biometric identity.
- Added campaign presets including a high-creativity Pierciina weird-editorial stress test.
- Added creative guardrails and prompt-assembly contract.
- Added canonical 5-step operating workflow.
- Added controlled test scenarios and weighted evaluation rubric with hard identity/product/non-blending gates.
- Added repository media-integration policy.
- Added static validation script.
- Added precise GitHub integration task for Claude.
