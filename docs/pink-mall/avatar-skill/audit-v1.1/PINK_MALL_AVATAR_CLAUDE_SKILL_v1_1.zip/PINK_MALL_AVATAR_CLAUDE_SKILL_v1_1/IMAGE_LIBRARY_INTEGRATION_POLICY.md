# Avatar Image Library Integration Policy v1.1

The skill metadata references 190 source JPEGs from `Avatarskill.rar` (77 INA, 76 SIS, 37 DUO). The source image archive is approximately 195 MB in the current working environment.

## Default policy

Do not duplicate or bulk-commit all 190 image files into the Git repository merely to integrate this skill.

Before adding image binaries, inspect the repository's existing media policy and determine whether it uses:

- Git LFS,
- external/object storage,
- a dedicated media repository,
- an existing asset acquisition path,
- or normal Git for approved reference subsets.

## Minimum requirement

The integrated skill must preserve the manifest paths and make it explicit where the actual image library is expected to live.

## If source images are not available to future Claude sessions

Propose one of these options for owner approval:

1. Git LFS for the complete 190-image source library.
2. Store only approved canonical reference images in-repo/LFS and keep the full archive external.
3. Use an existing PINK MALL media-storage convention if one already exists.

Do not silently choose a bulk-binary strategy that bloats the repository.

## Integrity

When images are integrated, verify every file SHA-256 against `AVATAR_LIBRARY_MANIFEST.json` before claiming the library is connected.
