#!/usr/bin/env python3
"""Static validator for PINK MALL Avatar Claude Skill v1.1.
No third-party dependencies required.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent

FILES = [
    "AVATAR_LIBRARY_MANIFEST.json",
    "CANONICAL_PACKS.json",
    "INA_AVATAR_BIBLE.json",
    "SIS_AVATAR_BIBLE.json",
    "DUO_LIBRARY.json",
    "BRAND_DNA.json",
    "SISTER_STYLE_PROFILES.json",
    "CAMPAIGN_STYLE_PRESETS.json",
    "TEST_SCENARIOS.json",
    "TEST_EVALUATION_RUBRIC.json",
]


def load(name):
    with (ROOT / name).open("r", encoding="utf-8") as f:
        return json.load(f)


def fail(msg):
    print(f"FAIL: {msg}")
    return 1


def main():
    errors = 0
    data = {}
    for name in FILES:
        p = ROOT / name
        if not p.exists():
            errors += fail(f"missing {name}")
            continue
        try:
            data[name] = load(name)
            print(f"PASS: JSON parses: {name}")
        except Exception as exc:
            errors += fail(f"{name}: {exc}")

    if errors:
        return 1

    manifest = data["AVATAR_LIBRARY_MANIFEST.json"]
    records = manifest.get("records", [])
    if len(records) != 190:
        errors += fail(f"manifest expected 190 records, found {len(records)}")
    else:
        print("PASS: manifest record count = 190")

    by_path = {r.get("relativePath"): r for r in records}
    if len(by_path) != len(records):
        errors += fail("duplicate relativePath values in manifest")
    else:
        print("PASS: manifest relative paths unique")

    subjects = {"INA": 0, "SIS": 0, "DUO": 0}
    for r in records:
        s = r.get("subject")
        if s in subjects:
            subjects[s] += 1
        else:
            errors += fail(f"unexpected subject in manifest: {s!r}")
    expected = {"INA": 77, "SIS": 76, "DUO": 37}
    if subjects != expected:
        errors += fail(f"subject counts {subjects}, expected {expected}")
    else:
        print(f"PASS: subject counts = {subjects}")

    refs = []
    packs = data["CANONICAL_PACKS.json"]
    for subject in ("INA", "SIS", "DUO"):
        for pack_name, paths in packs.get(subject, {}).items():
            if isinstance(paths, list):
                for path in paths:
                    refs.append((subject, f"CANONICAL_PACKS.{pack_name}", path))

    duo = data["DUO_LIBRARY.json"].get("compositions", {})
    for comp, spec in duo.items():
        for key in ("preferred", "alternates"):
            for path in spec.get(key, []):
                refs.append(("DUO", f"DUO_LIBRARY.{comp}.{key}", path))

    for subject, src, path in refs:
        rec = by_path.get(path)
        if not rec:
            errors += fail(f"reference missing from manifest: {src}: {path}")
            continue
        if rec.get("subject") != subject:
            errors += fail(f"subject mismatch: {src}: {path}: manifest={rec.get('subject')} expected={subject}")
    if not errors:
        print(f"PASS: {len(refs)} canonical/duo references resolve and preserve subject labels")

    profiles = data["SISTER_STYLE_PROFILES.json"]
    for key in ("INA", "SIS", "DUO"):
        if key not in profiles:
            errors += fail(f"missing style profile {key}")
    presets = data["CAMPAIGN_STYLE_PRESETS.json"].get("presets", {})
    needed = {"hero_banner", "new_in", "accessories_spotlight", "sister_battle", "story_vertical", "pierciina_weird_editorial"}
    missing = needed - set(presets)
    if missing:
        errors += fail(f"missing campaign presets: {sorted(missing)}")
    else:
        print("PASS: campaign presets complete")

    tests = data["TEST_SCENARIOS.json"].get("tests", [])
    for t in tests:
        if t.get("preset") not in presets:
            errors += fail(f"test {t.get('id')} references unknown preset {t.get('preset')}")
    if not errors:
        print(f"PASS: {len(tests)} test scenarios reference valid presets")

    weights = sum(c.get("weight", 0) for c in data["TEST_EVALUATION_RUBRIC.json"].get("criteria", []))
    if abs(weights - 1.0) > 1e-9:
        errors += fail(f"evaluation weights sum to {weights}, expected 1.0")
    else:
        print("PASS: evaluation weights sum to 1.0")

    if errors:
        print(f"\nVALIDATION FAILED: {errors} issue(s)")
        return 1
    print("\nVALIDATION PASS — PINK MALL Avatar Skill v1.1")
    return 0


if __name__ == "__main__":
    sys.exit(main())
